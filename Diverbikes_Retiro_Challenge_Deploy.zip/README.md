# Diverbikes Retiro Challenge — Demo V2

Demo estática preparada para GitHub Pages, Netlify o Vercel.

## Identidad visual
- Logo: recorte de un mapa promocional público de Diverbikes.
- Naranja principal derivado de ese mismo material: `#EB6909`.
- Antes de producción, sustituir por el archivo maestro del logo/manual de marca si Diverbikes lo facilita.

## Ejecutar
Abrir `index.html` en un navegador o servir esta carpeta con cualquier servidor estático.

## Publicar rápido
### GitHub Pages
Subir el contenido a la raíz de un repositorio y activar Pages desde la rama principal.

### Netlify / Vercel
Importar la carpeta/repo como sitio estático; no requiere build command.

## Demo
Cumpleaños tiene el flujo completo. Familia y Empresas aparecen en selección y reutilizarán el mismo motor en la siguiente iteración.
